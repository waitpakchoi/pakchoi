﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Leap_year
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        public static Int64 Years(Int64 Input)
        {
            
            if (Input > Int32.MaxValue)
            {
                throw (new AException("您输入的值太大了！请重新输入！"));
            }
            else if (Input < Int32.MinValue)
            {
                throw (new AException("您输入的值太小了！请重新输入！"));
            }
            else 
            {
                if (Input % 4 == 0 && Input % 100 != 0 || Input / 4 == 100 || Input / 4 == -100)
                {
                    MessageBox.Show("您输入的是闰年！", "年份提示");
                }
                else
                {
                    MessageBox.Show("您输入的不是闰年！","年份提示");
                }
            }
            return Input;
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            unchecked
            {
                try
                {
                    Int64 panduan = Int64.Parse(textBox1.Text);
                    Int64 shuzi = Years(panduan);
                }
                catch (AException baocuo)
                {
                    MessageBox.Show(""+ baocuo.Message,"错误提示");
                }
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }
    }
    public class AException : ApplicationException
    {
        public AException(string message)
            : base(message)
        {
        }
    }
}
